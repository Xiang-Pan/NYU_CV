<!--
 * @Author: Xiang Pan
 * @Date: 2021-12-15 13:45:26
 * @LastEditTime: 2021-12-15 13:45:26
 * @LastEditors: Xiang Pan
 * @Description: 
 * @FilePath: /assignment3/README.md
 * @email: xiangpan@nyu.edu
-->
# Environment
git clone https://github.com/rmislam/PythonSIFT

make sure all the data in ./docs folder